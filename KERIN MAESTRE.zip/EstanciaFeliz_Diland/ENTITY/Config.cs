﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public static class Config
    {
        public const string FILENAME_HUESPEDES = "huespedes.txt";
        public const string FILENAME_HABITACIONES = "habitaciones.txt";
        public const string FILENAME_RESERVAS = "reservas.txt";
    }
}
